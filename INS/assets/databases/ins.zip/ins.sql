PRAGMA encoding = "UTF-8";
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS Building (
    idBuilding INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    mapPath TEXT NOT NULL );

CREATE TABLE IF NOT EXISTS EntryPoint (
    idEntryPoint INTEGER PRIMARY KEY AUTOINCREMENT,
    latitude REAL NOT NULL,
    longitude REAL NOT NULL,
    floor INTEGER NOT NULL,
    name TEXT NOT NULL,
    Building_idBuilding INTEGER NOT NULL,
    CONSTRAINT fk_EntryPoint_Building
        FOREIGN KEY (Building_idBuilding)
        REFERENCES Building (idBuilding)
        ON DELETE CASCADE
        ON UPDATE CASCADE );

DELETE FROM EntryPoint;
DELETE FROM Building;

INSERT INTO Building (name, mapPath) VALUES ("Logement de Baptiste MORELLE", "unknown");
INSERT INTO EntryPoint (latitude, longitude, floor, name, Building_idBuilding) VALUES (49.416833, 2.821595, 1, "Porte d'entrée", (SELECT MAX( idBuilding) FROM Building));

INSERT INTO Building (name, mapPath) VALUES ("Logement de Clément CONTINI", "unknown");
INSERT INTO EntryPoint (latitude, longitude, floor, name, Building_idBuilding) VALUES (49.412752, 2.814000, 1, "Porte d'entrée", (SELECT MAX (idBuilding) FROM Building));
INSERT INTO EntryPoint (latitude, longitude, floor, name, Building_idBuilding) VALUES (49.412693, 2.813891, 1, "Porte du jardin", (SELECT MAX (idBuilding) FROM Building));

INSERT INTO Building (name, mapPath) VALUES ("Pierre Guillaumat 1", "unknown");
INSERT INTO EntryPoint (latitude, longitude, floor, name, Building_idBuilding) VALUES (49.40023, 2.80006, 1, "Porte d'entrée principale", (SELECT MAX(idBuilding) FROM Building));
INSERT INTO EntryPoint (latitude, longitude, floor, name, Building_idBuilding) VALUES (49.40056, 2.80115, 1, "Porte du jardin", (SELECT MAX(idBuilding) FROM Building));
